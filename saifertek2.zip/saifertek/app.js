document.getElementById('createFileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const filename = document.getElementById('filename').value;
    const content = document.getElementById('content').value;
    const password = document.getElementById('password').value;

    fetch('/createFile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, content, password })
    })
    .then(response => {
        if (response.ok) {
            alert('File created successfully!');
        } else {
            alert('Failed to create file.');
        }
    })
    .catch(error => console.error('Error:', error));
});

document.getElementById('listFilesBtn').addEventListener('click', function() {
    fetch('/getFiles')
    .then(response => response.json())
    .then(files => {
        const fileList = document.getElementById('fileList');
        fileList.innerHTML = ''; // Clear current list
        files.forEach(file => {
            const listItem = document.createElement('li');
            listItem.textContent = file;
            fileList.appendChild(listItem);
        });
    })
    .catch(error => console.error('Error:', error));
});

document.getElementById('getFileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const filename = document.getElementById('getFilename').value;
    const password = document.getElementById('getFilePassword').value;

    fetch(`/getFile?filename=${encodeURIComponent(filename)}&password=${encodeURIComponent(password)}`)
    .then(response => {
        if (!response.ok) {
            throw new Error('File not found');
        }
        return response.text();
    })
    .then(content => {
        document.getElementById('fileContent').textContent = content;
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to retrieve file.');
    });
});
